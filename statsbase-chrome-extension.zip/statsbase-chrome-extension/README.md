# IG Panel – StatsBase

- Profil gridindeki `/p/` ve `/reel/` linklerinden örneklem toplar.
- Her link için modal açar, **DOM** metninden beğeni/yorum/izlenme yakalar.
- Ortalamaları ve **engagement (%)** hesaplar.
- Paneldeki tüm rakamlar için **kopyala** ikonu ve **toast** bulunur.
- Sağ üstten **Son 12/24/36/60** seç, **Yenile** ile tekrar tara.

> Not: Instagram DOM'u sık değişir. Seçiciler çoklu fallback içerir. Görüntülenme sayısı bazı içerik türlerinde/hesaplarda görünmeyebilir.
