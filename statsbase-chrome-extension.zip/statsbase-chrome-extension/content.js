// content.js — Sadece beğeni odaklı scraper (API yok, modal + DOM)
const sleep = (ms)=>new Promise(r=>setTimeout(r,ms));
const PANEL_ID="__ig_panel_statsbase__";

const human = n =>
  n==null ? '-' :
  n>=1e6 ? (n/1e6).toFixed(1).replace(/\.0$/,'')+'M' :
  n>=1e3 ? (n/1e3).toFixed(1).replace(/\.0$/,'')+'K' : String(n);

// 1) Daha kapsayıcı sayı ayrıştırıcı
function numberFromText(input){
  if (!input) return null;
  const raw = String(input).replace(/\u00A0/g,' ').trim();
  const norm = raw
    .replace(/(\d)\.(?=\d{3}(\D|$))/g,'$1') // 1.234.567 -> 1234567
    .replace(/,(\d)/g,'.$1');               // 12,3 -> 12.3

  // “1.2 milyon / million / mn”
  let m = norm.match(/(\d+(?:\.\d+)?)[\s-]*(milyon|million|mn)\b/i);
  if (m) return Math.round(parseFloat(m[1]) * 1e6);

  // “12 bin / thousand”
  m = norm.match(/(\d+(?:\.\d+)?)[\s-]*(bin|thousand)\b/i);
  if (m) return Math.round(parseFloat(m[1]) * 1e3);

  // “292K / 292 K / 1.2M / 1.2 M / 292B (TR’de ‘bin’)”
  m = norm.match(/(\d+(?:\.\d+)?)[\s]*([kmb])\b/i);
  if (m) {
    const n = parseFloat(m[1]);
    const u = m[2].toUpperCase();
    return Math.round(n * (u === 'M' ? 1e6 : 1e3)); // K or B -> 1e3
  }

  m = norm.match(/(\d+(?:\.\d+)?)/);
  if (!m) return null;
  const n = parseFloat(m[1]);
  return isFinite(n) ? Math.round(n) : null;
}

function toast(msg){
  const t=document.createElement('div');
  t.textContent=msg;
  t.style.cssText=`
    position:fixed; right:20px; bottom:20px; z-index:2147483647;
    background:#222; color:#fff; padding:10px 12px; border-radius:10px;
    font:500 13px system-ui,Arial; box-shadow:0 6px 20px rgba(0,0,0,.5); opacity:.98`;
  document.documentElement.appendChild(t);
  setTimeout(()=>t.remove(),1500);
}

function ensurePanel(){
  let el=document.getElementById(PANEL_ID);
  if(el) return el;

  el=document.createElement('div');
  el.id=PANEL_ID;
  el.style.cssText='position:fixed;top:16px;right:16px;z-index:2147483647;font-family:system-ui,Arial;';
  el.innerHTML=`
  <div style="background:#111;color:#eee;border:1px solid #2a2a2a;border-radius:14px;min-width:340px;padding:14px 16px;box-shadow:0 8px 28px rgba(0,0,0,.45); position:relative">
    <!-- Sağ üst: kapatma -->
    <button id="igp-close" aria-label="Kapat" style="position:absolute;top:8px;right:10px;background:transparent;border:none;color:#aaa;font-size:18px;cursor:pointer;line-height:1">×</button>

    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
      <div style="font-weight:800;font-size:14px">IG Panel</div>
    </div>

    <div style="display:flex;gap:10px;align-items:center;margin-bottom:10px">
      <button id="igp-run"  style="padding:8px 12px;border:1px solid #2c2c2c;border-radius:10px;background:#1c1c1c;color:#fff;cursor:pointer">Analiz et</button>

      <!-- Durum metni buraya taşındı -->
      <div id="igp-status" style="margin-left:4px;font-size:12px;color:#bdbdbd">Hazır</div>

      <label style="margin-left:auto;font-size:12px;color:#aaa;display:flex;gap:6px;align-items:center">
        İçerik Sayısı:
        <input id="igp-sample" type="number" min="1" max="60" step="1" value="12"
          style="width:40px;background:#181818;color:#fff;border:1px solid #2c2c2c;border-radius:8px;padding:6px 8px;text-align:center">
      </label>
    </div>

    <div style="font-size:12px;font-weight:700;margin-bottom:8px">
      Bulunan post linki: <b id="igp-link-count">-</b>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div style="border:1px solid #2a2a2a;border-radius:10px;padding:10px;background:#131313">
        <div style="color:#bcbcbc">Takipçi</div><b id="igp-followers">-</b>
      </div>
      <div style="border:1px solid #2a2a2a;border-radius:10px;padding:10px;background:#131313">
        <div style="color:#bcbcbc">Sayı</div><b id="igp-sample-out">-</b>
      </div>

      <div style="border:1px solid #2a2a2a;border-radius:10px;padding:10px;background:#131313">
        <div style="color:#bcbcbc">Ort. Beğeni</div><b id="igp-avg-like">-</b>
      </div>
      <div style="border:1px solid #2a2a2a;border-radius:10px;padding:10px;background:#131313;cursor:pointer"
           id="igp-eng-card" title="Tıklayınca panoya kopyalanır">
        <div style="color:#bcbcbc">Etkileşim Oranı</div><b id="igp-eng">-</b>
      </div>
    </div>

    <div style="margin-top:8px;color:#b0b0b0;font-size:12px">
       * CultureBase tarafından geliştirilmiştir
    </div>
  </div>`;

  document.documentElement.appendChild(el);

  el.querySelector('#igp-close').onclick=()=>el.remove();
  el.querySelector('#igp-run').onclick=()=>run();
  el.querySelector('#igp-eng-card').onclick=()=>{
    const v = document.getElementById('igp-eng')?.textContent || '';
    navigator.clipboard?.writeText(v).then(()=>toast('Etkileşim oranı kopyalandı'));
  };

  return el;
}

function setStatus(t){ const s=document.getElementById('igp-status'); if(s) s.textContent=t; }
function setText(id,val){ const e=document.getElementById(id); if(e) e.textContent=val; }

// Takipçi (daha dayanıklı seçim)
// 2) Takipçiyi daha sağlam topla (meta fallbacks + ayrık "K/M")
function getFollowerCount(){
  // A) Meta description (çoğu profilde var)
  const meta = document.querySelector('meta[property="og:description"]')
           || document.querySelector('meta[name="description"]');
  if (meta?.content){
    // "X followers, Y following" veya "X takipçi, Y takip"
    const m = meta.content.match(/([\d\.\,KMkm]+)\s*(followers|takipçi)/);
    if (m){
      const n = numberFromText(m[1]);
      if (n) return n;
    }
  }

  // B) Doğrudan /followers/ linki ve altındaki span/div'ler
  const link = document.querySelector('a[href$="/followers/"]');
  if (link){
    const candidates = [
      link.getAttribute('title'),
      link.textContent,
      ...[...link.querySelectorAll('span,div,strong')].map(n =>
        (n.getAttribute?.('title') || n.textContent))
    ].filter(Boolean);
    for (const t of candidates){
      const n = numberFromText(t);
      if (n) return n;
    }
  }

  // C) Header sayacı (li/span) – locale bağımsız etiket yakalama
  const label = [...document.querySelectorAll('li, a, span, div')]
    .find(n => /takipçi|followers/i.test(n.textContent||''));
  if (label){
    const host = label.closest('li') || label.parentElement;
    const pieces = host ? [...host.querySelectorAll('span,div,strong')] : [];
    // text parçalarını birleşik de dene (ör. "292" + "K")
    const joined = pieces.map(n=>n.textContent.trim()).join(' ');
    let n = numberFromText(joined);
    if (n) return n;
    for (const p of pieces){
      n = numberFromText(p.getAttribute?.('title') || p.textContent);
      if (n) return n;
    }
  }

  return null;
}

function collectLinks(){
  const as=[...document.querySelectorAll('a[href*="/p/"], a[href*="/reel/"]')];
  const hrefs=as.map(a=> (a.href||a.getAttribute('href')||'').split('?')[0])
                .filter(u=>/\/(p|reel)\/[^/]+\/?$/.test(u));
  return [...new Set(hrefs)];
}

async function closeModal(){
  document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));
  await sleep(150);
  const btn = document.querySelector('svg[aria-label="Kapat"], svg[aria-label="Close"]');
  if (btn) { btn.closest('button')?.click(); await sleep(150); }
}

function readLikesFromModal(){
  const root = document.querySelector('div[role="dialog"]') || document.querySelector('article[role="presentation"]');
  if(!root) return null;

  let like = null;
  const likeNode = [...root.querySelectorAll('span, a, div')].find(n=>/beğen(i|me)|likes?/i.test(n.textContent||''));
  if(likeNode){
    like = numberFromText(likeNode.textContent);
  } else {
    const candidates = [...root.querySelectorAll('section span')]
      .map(s=>numberFromText(s.textContent))
      .filter(n=>n && n>0);
    like = candidates.length ? Math.max(...candidates) : null;
  }
  return like;
}

async function openPostAndRead(url){
  const a=[...document.querySelectorAll('a[href*="/p/"], a[href*="/reel/"]')]
            .find(x=>(x.href||x.getAttribute('href')||'').startsWith(url));
  if(a){ a.click(); } else { window.open(url, "_blank"); }
  for(let i=0;i<30;i++){
    if(document.querySelector('div[role="dialog"], article[role="presentation"]')) break;
    await sleep(150);
  }
  await sleep(250);
  const like = readLikesFromModal();
  await closeModal();
  await sleep(150);
  return like;
}

async function run(){
  ensurePanel();

  const links = collectLinks();
  setText('igp-link-count', links.length);

  const followers = getFollowerCount();
  setText('igp-followers', followers?human(followers):'-');

  const inputEl = document.getElementById('igp-sample');
  let sample = parseInt(inputEl?.value || '12', 10);
  if (!isFinite(sample) || sample < 1) sample = 1;

  const pick = links.slice(0, sample);
  setText('igp-sample-out', pick.length);

  setStatus('Taranıyor…');

  const likes=[];
  let errors=0;

  for(let i=0;i<pick.length;i++){
    setStatus(`Açılıyor (${i+1}/${pick.length})…`);
    try{
      const like = await openPostAndRead(pick[i]);
      if(like!=null) likes.push(like);
    }catch(e){ errors++; }
  }

  const avg = arr => arr.length ? Math.round(arr.reduce((a,b)=>a+b,0)/arr.length) : null;
  const avgLikes = avg(likes);
  setText('igp-avg-like', human(avgLikes));

  // ER: (Ort. Beğeni / Takipçi) * 100  → "x,xx%"
  let er = null;
if (followers && avgLikes != null) er = (avgLikes / followers) * 100;
// Türkçe yüzde biçimi, 2 ondalık
const erText = er == null
  ? '-'
  : new Intl.NumberFormat('tr-TR', {minimumFractionDigits:2, maximumFractionDigits:2})
      .format(er) + '%';
setText('igp-eng', erText);

  setStatus(`Hazır${errors?` • ${errors} hata`:''}`);
}

// Otomatik çalıştırma yok
(function(){ ensurePanel(); })();
